export const product = "Fitsol"
